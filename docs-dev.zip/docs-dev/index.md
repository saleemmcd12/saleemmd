---
layout: default
title: Home
nav_order: 1
description: "The fastest and most flexible Probabilistic Data Structures"
permalink: /
---

# ProbabiliSaaS

ProbabiliSaaS is a collection of Probabilistic Data Structures with the ability to scale up and down, and expire elements after a set time. It uses our proprietary, patent pending Data structures. Currently we offer Bloom Filter and Cuckoo Filter variants. HyperLogLog with an expiration is in the making.

## Primary features

* Supports scale up and down autonomously to reduce memory footprint.
* Support expiration of elements after set time. Similar to 'EXPIRE'.
* Offers unique API beyond 'RedisBloom'.

## Give it a try

Try an instance using our free tier service at [ProbabiliSaaS Clouds](https://cloud.probabilisaas.com)

Once loaded you can interact with our using any of the supported [client libraries](/clients)

Here we'll use [ProbabiliSaaS Python client](https://pypi.org/project/ProbabiliSaaS/) to create a bloom filter, insert elements and watching how element s are expired.

```python
from probabilisaas import ProbSaas

# Connect to ProbabiliSaas
con = ProbSaas(host='localhost', port=6379)

con.bf_reserve("test", 1000, 0.01)
con.bf_add("test", "42")
```

For additional demos please see visit [Demos](https://github.com/FalkorDB/demos).

## Client libraries

Language-specific clients have been written by the community and the ProbabiliSaaS team.
The full list and links can be found on the [Clients](/clients) page.

## Mailing List / Forum

Got questions? Please contact us at the [ProbabiliSaaS forum](https://github.com/orgs/ProbabiliSaaS/discussions).

## License

ProbabiliSaaS software is licensed under a proprietary license.