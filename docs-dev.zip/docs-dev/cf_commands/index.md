---
title: "Cuckoo Filter"
description: Cuckoo Filter Commands
nav_order: 2
has_children: true
---

# Commands

## Efficient Cuckoo Filter Features

Efficient Cuckoo Filter (PCF) is a proprietary variant of Cuckoo Filter. It supports sliding windows functionality which expire entries after a set time. This allows new use cases such as:

* Time-sensitive deduplication.
* Clear old filter members.
* Get age of a member.